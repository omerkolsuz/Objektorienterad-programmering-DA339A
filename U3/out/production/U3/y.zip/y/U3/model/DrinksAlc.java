package model;

/**
 * Subklass till klassen Drinks som definierar om det är en alkoholhaltig dryck.
 * @author Ibrahim
 */

public class DrinksAlc extends Drinks {

    private double alcPercent;

    /**
     * Konstruktor för att definiera namn, pris och alkoholhalt på dryck.
     * @param name
     * @param price
     * @param alcPercent
     */
    public DrinksAlc(String name, int price, double alcPercent) {
        super(name, price);
        this.alcPercent = alcPercent;
    }

    /**
     * Metod för att definiera alkoholhalt på dryck och returna som double
     * @return alcPercent - alkoholhalt på dryck
     */

    public double getAlcPercent() {
        return alcPercent;
    }

    /**
     * Metod för att sätta alkoholhalt på dryck
     * @param alcPercent
     */
    public void setAlcPercent(double alcPercent) {
        this.alcPercent = alcPercent;
    }

    /**
     * Metod för att skapa en sträng gällande alkoholhaltiga drycker
     * @return sträng med namn, pris och alkoholhalt för dryck
     */

    public String toString() {
        String textOut = super.toString() + ", " + alcPercent + "%";
        return textOut;
    }

}
