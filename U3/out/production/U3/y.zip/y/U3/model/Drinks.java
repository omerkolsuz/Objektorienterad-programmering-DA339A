package model;

/**
 * Sublklassens syfte är skapa dryckesobjekt med hjälp av klassen för produkter.
 * @author Ömer & Ibrahim
 */

public class Drinks extends model.Product
{
    /**
     * Konstruktor för dryck som ärver av klassen Product
     * @param name
     * @param price
     */
    public Drinks(String name, int price)
    {
        super(name, price);
    }


    /**
     * Metod som genererar en sträng av namn och pris på en dryck.
     * @return En sträng som visar namn och pris.
     * @author Ibrahim
     */
    @Override
    public String toString() {
        String textOut = super.toString() ;
        return textOut;
    }
}

