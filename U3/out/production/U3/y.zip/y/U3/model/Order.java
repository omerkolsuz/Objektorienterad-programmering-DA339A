package model;

import java.util.ArrayList;

/**
 * Klass som håller koll på ordrar med hjälp av objekt från Product. Skapar en ArrayList med valda produkter.
 */
public class Order
{
    ArrayList<Product> product = new ArrayList<>();
    private double price;
    private boolean pizzaOK = false;
    private int id;

    /**
     * Konstruktor för order som visar ID och pris.
     * @param id
     */
    public Order(int id )
    {
        price = 0;
        this.id = id;
    }

    /**
     * Metod för att genom boolean dubbelkolla att en pizza har beställts och inte bara dryck.
     * @return returnerar boolean om pizza finns med i order
     */
    public boolean isPizzaOK() {
        return pizzaOK;
    }

    /**
     * Metod för att sätta ett ID på en order.
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Metod som först kontrollerar att en instans av Pizza finns med i order och sedan lägger till produkt och pris på
     * produkten i en order.
     * @param product
     */
    public void addProduct(Product product)
    {
        if (product instanceof Pizza) {
            pizzaOK = true;
        }
       this.product.add(product);
       price = price + product.getPrice();
    }

    /**
     * Metod för att skapa strängar av orderinformation som sedan kan skrivas ut i GUI.
     * @return returnerar en sträng med information om produkt/order.
     */
    public String[] getOrdersInfo(){
        String []infoStrings = new String[product.size()];
        for (int i =0; i<product.size(); i++){
            infoStrings[i] = product.get(i).toString();
        }
        return infoStrings;
    }

    /**
     * Metod för att hämta pris.
     * @return returnerar en double av pris.
     */
    public double getPrice() {
        return price;
    }

    /**
     * Metod för att skapa en sträng av orderinformation som visar orderns ID och dess pris.
     * @return returnerar sträng med ID och pris.
     */

    public String toString()
    {
        String textOut = String.format("%s %s", id + ", " ,price + "kr");
        return textOut;
    }
}
