package model;

/**
 * Superklass som genom interface Item skapar de olika produkter som går att beställa. Innehåller de variabler som används gemensamt
 * av dryck, alkoholhaltig dryck samt pizza.
 * @author Ibrahim & Ömer
 */
public class Product implements Item {
    private String name;
    private double price;

    /**
     * Constructor för alla produkter innehållande pris och namn.
     * @param name sträng för namn av produkt
     * @param price double för pris av produkt
     */
    public Product(String name, double price) {
        {
            this.name = name;
            this.price = price;
        }
    }
    //region Getters & Setters
    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }

    //endregion

    /**
     * Metod för att skapa sträng av produkters namn och pris.
     * @return returnerar en sträng för produkt som innehåller namn och pris.
     */
    public String toString()
    {
        return String.format("%s %s", name + ", " ,price + "kr");
    }
}
