package model;

import java.util.ArrayList;

/**
 * Klass som lagrar alla ordrar ifrån Order klassen.
 * @author ibrahim
 */
public class OrderManagement
{
    ArrayList <Order> allOrders;

    /**
     * Skapar en ny lista av alla ordrar gjorda av användaren
     */
    public OrderManagement(){
        allOrders = new ArrayList<>();
    }

    /**
     * Skapar själva ordern och ger den ett ID med objekt från Order
     * @param order
     */
    public void addOrder (Order order){
        order.setId(getCurrentId());
        allOrders.add(order);
    }

    /**
     * Metod för att fylla ArrayList med lagrade ordrar.
     * @return returnerar en ArrayList med alla order sparade.
     * @author Ibrahim
     */
    public Order[] getAllOrders() {
        Order [] returnOder = new Order[allOrders.size()];
        for (int i =0; i < allOrders.size(); i ++){
            returnOder[i] = allOrders.get(i);
        }
        return returnOder;
    }

    /**
     * Skapar ett ID för varje order.
     * @return returnerar en orders ID, dvs index på ordern.
     */
    public int getCurrentId(){
        return allOrders.size();
    }
}
