package controller;

//only imports what is strictly necessary from view-package;

import model.*;
import view.MainFrame;
import view.ButtonType;

import javax.swing.*;
import java.util.ArrayList;

/**
 * Controller är länken mellan entityklasserna och boundaryklasserna. Klassens syfte är att genom användarens input skapa
 * olika ordrar men även att visa de produkter som finns valbara för menyn. Klassen hanterar vad som händer vid användarens
 * olika val i GUI.
 * @author Ömer & Ibrahim
 */
public class Controller {
    private MainFrame view;
    private Order currentOrder;
    private ButtonType currentLeftMenu = ButtonType.NoChoice;


    private ArrayList<Pizza> pizzaMenu;
    private ArrayList<Drinks> drinkMenu;

    Pizza pizza;
    Drinks drinks;
    OrderManagement orderManagement;

    /**
     * Metoden skapar objekt av OrderManagement och Order. Metoden kallar på de metoder som skapar innehållet för meny av
     * pizza och dryck. Metod aktiverar alla knappar i GUI men avaktiverar Add och View Selected Order.
     */
    public Controller() {
        orderManagement = new OrderManagement();
        currentOrder = new Order(0);
        createPizza();
        createDrinks();
        view = new MainFrame(1000, 500, this);
        view.enableAllButtons();
        view.disableAddMenuButton();
        view.disableViewSelectedOrderButton();
    }

    /**
     * Metoden skapar de olika pizzor som finns valbara för användaren i GUI. Pizzorna läggs in i en ArrayList.
     * @author Ömer
     */
    public void createPizza() {
        pizzaMenu = new ArrayList<>();
        pizza = new Pizza("Pizza Special", 65, new PizzaToppings[]{PizzaToppings.tomato_sauce, PizzaToppings.mozzarella, PizzaToppings.pepperoni, PizzaToppings.pineapple});
        pizzaMenu.add(pizza);
        pizza = new Pizza("Pizza Simple", 60, new PizzaToppings[]{PizzaToppings.tomato_sauce, PizzaToppings.cheese});
        pizzaMenu.add(pizza);
        pizza = new Pizza("Pizza Freshness", 70, new PizzaToppings[]{PizzaToppings.tomato_sauce, PizzaToppings.onion});
        pizzaMenu.add(pizza);
        pizza = new Pizza("Pizza Tomatolicious",75, new PizzaToppings[]{PizzaToppings.tomato_sauce, PizzaToppings.sun_dried_tomatoes});
        pizzaMenu.add(pizza);
        pizza = new Pizza("Ibrahims Pizza", 85, new PizzaToppings[]{PizzaToppings.tomato_sauce, PizzaToppings.mozzarella, PizzaToppings.cheese});
        pizzaMenu.add(pizza);

    }

    /**
     * Metoden skapar de drycker som finns valbara för användaren i GUI. Den använder sig av objekt från klasserna
     * Drinks och DrinksAlc.
     * @author Ömer
     */

    public void createDrinks() {
        drinkMenu = new ArrayList<>();
        //Alcoholic Drinks
        drinkMenu.add(new DrinksAlc("Beer", 67, 5.0));
        drinkMenu.add(new DrinksAlc("Wine", 75, 12.0));

        //Non-Alcoholic Drinks
        drinkMenu.add(new Drinks("Coffee", 45));
        drinkMenu.add(new Drinks("Fanta", 25));

    }

    /**
     * Metod för att skapa strängar av de olika tillgängliga pizzor.
     * @return returnerar sträng med olika pizzor
     */
    private String[] getPizzaStrings() {
        String[] infoStrings = new String[pizzaMenu.size()];
        for (int i = 0; i < infoStrings.length; i++) {
            infoStrings[i] = pizzaMenu.get(i).toString();
        }

        return infoStrings;
    }
    /**
     * Metod för att skapa strängar av de olika tillgängliga drycker.
     * @return returnerar sträng med olika drycker
     */
    private String[] getDrinksStrings() {
        String[] infoStrings = new String[drinkMenu.size()];

        for (int i = 0; i < infoStrings.length; i++) {
            infoStrings[i] = drinkMenu.get(i).toString();
        }
        return infoStrings;
    }
    /**
     * Metod för att skapa strängar orderhistorik med objekt av alla gjorda ordrar.
     * @return returnerar sträng med olika ordrar
     */

    private String[] getOrderHistoryStrings() {
        Order[] orders = orderManagement.getAllOrders();
        String[] infoStrings = new String[orders.length];
        for (int i = 0; i < orders.length; i++) {
            infoStrings[i] = orders[i].toString();
        }
        return infoStrings;
    }


    /**
     * Switchmetod för olika tillgängliga knappar och de scenario som är möjliga via GUI.
     * @param button
     */
    public void buttonPressed(ButtonType button) {

        switch (button) {
            case Add:
                addItemToOrder(view.getSelectionLeftPanel());
                break;

            case Food:
                setToFoodMenu();
                break;

            case Drinks:
                setToDrinkMenu();
                break;

            case Clear:
                clearPanels();
                break;

            case OrderHistory:
                setOrderHistoryMenu();
                break;

            case Order:
                placeOrder(view.getSelectionLeftPanel());
                break;

            case ViewOrder:
                viewSelectedOrder();
                break;
        }
    }

    /**
     * Metod som möjliggör att lägga till pizza och dryck till order via en switch med hjälp av knappen add. Metoden
     * kontrollerar att användaren är 18 eller äldre för köp av alkoholhaltiga drycker. Om användaren är yngre än 18, visas
     * ett felmeddelande. Uppdaterar label för pris när nya produkter läggs till i order. De tillagda produkterna läggs
     * till i högra panelen i GUI.
     * @param selectionIndex
     */
    public void addItemToOrder(int selectionIndex) {
        if (selectionIndex != -1) { // if something is selected in the left menu list
            switch (currentLeftMenu) {
                case Food:
                    currentOrder.addProduct(pizzaMenu.get(selectionIndex));
                    break;
                case Drinks:
                    if (drinkMenu.get(selectionIndex) instanceof DrinksAlc) {
                        String input = JOptionPane.showInputDialog("Var vänlig ange ålder!");
                        int age = Integer.parseInt(input);
                        if (age > 17) {
                            currentOrder.addProduct(drinkMenu.get(selectionIndex));

                        } else {
                            JOptionPane.showMessageDialog(null, "Du får inte köpa alkohol");
                        }
                    } else {
                        currentOrder.addProduct(drinkMenu.get(selectionIndex));
                        break;
                    }
            }
            view.populateRightPanel(currentOrder.getOrdersInfo()); //update right panel with new item - this takes a shortcut in updating the entire information in the panel not just adds to the end
            view.setTextCostLabelRightPanel("Total cost of order: " + currentOrder.getPrice()); //set the text to show cost of current order
        }
    }

    /**
     * Metod som visar den valda orderns innehåll i den högra panelen av GUI. Metoden använder sig av orderManagement
     * för att visa lagrad orderhistorik.
     */
    public void viewSelectedOrder() {
        int selectionIndex = view.getSelectionLeftPanel();
        view.setTextCostLabelRightPanel("Total cost of order: No order chosen");
        if ((selectionIndex != -1) && currentLeftMenu == ButtonType.OrderHistory) {
            Order thisOrder = orderManagement.getAllOrders()[selectionIndex];
            view.populateRightPanel(thisOrder.getOrdersInfo());

            view.setTextCostLabelRightPanel("Total cost of order: " + thisOrder.getPrice()); //set the text to show cost of current order
        }
    }

    /**
     * Metod som visar upp matlistan/pizzalistan när användaren trycker på Food-knappen. Metoden visar även pris i för
     * vald produkt i GUI.
     */
    public void setToFoodMenu()
    {
        currentLeftMenu = ButtonType.Food;
        view.populateLeftPanel(getPizzaStrings());
        view.populateRightPanel(currentOrder.getOrdersInfo()); //update left panel with new item - this takes a shortcut in updating the entire information in the panel not just adds to the end
        view.setTextCostLabelRightPanel("Total cost of order: " + currentOrder.getPrice()); //set the text to show cost of current order
        view.enableAllButtons();
        view.disableFoodMenuButton();
        view.disableViewSelectedOrderButton();
    }

    /**
     * Metod som visar upp dryckeslistan när användaren trycker på Drinks-knappen. Metoden visar även pris i för
     * vald produkt i GUI.
     */
    public void setToDrinkMenu()
    {
        currentLeftMenu = ButtonType.Drinks;
        view.populateLeftPanel(getDrinksStrings());
        view.populateRightPanel(currentOrder.getOrdersInfo()); //update left panel with new item - this takes a shortcut in updating the entire information in the panel not just adds to the end
        view.setTextCostLabelRightPanel("Total cost of order: " + currentOrder.getPrice()); //set the text to show cost of current order
        view.enableAllButtons();
        view.disableDrinksMenuButton();
        view.disableViewSelectedOrderButton();
    }

    /**
     * Metod när användaren väljer Order History skapa en lista av de ordrar som gjorts.
     */
    public void setOrderHistoryMenu()
    {
        currentLeftMenu = ButtonType.OrderHistory;
        view.clearRightPanel();
        view.populateLeftPanel(getOrderHistoryStrings());
        view.enableAllButtons();
        view.disableAddMenuButton();
        view.disableOrderButton();
    }

    /**
     * Metod för att tömma höger panelen innan ny order skapas och tömmer den nuvarande ordern.
     * @author Ibrahim
     */
    public void clearPanels()
    {
        currentOrder = new Order(0);
        view.clearRightPanel();
        view.enableAllButtons();
    }

    /**
     * Metoden kallas när användaren skapar en ny order. Metoden lägger till nuvarande order från högra panelen till en lista i
     * OrderManagement för att spara orderhistoriken. Metoden uppdaterar även pris. Metoden tömmer högra panelen via clearPanels();
     * Metoden kontrollerar genom en boolean och metoden isPizzaOK att beställningen innehåller minst en pizza. Om beställningen inte
     * innehåller en pizza visas ett felmeddelande.
     * @param selectionIndex
     */
    public void placeOrder(int selectionIndex)
    {
        if (currentOrder.isPizzaOK()) {
            view.populateRightPanel(currentOrder.getOrdersInfo());
            view.setTextCostLabelRightPanel("TOTAL COST: " + currentOrder.getPrice());
            orderManagement.addOrder(currentOrder);
            clearPanels();
            view.enableAllButtons();
            view.disableAddMenuButton();
            view.disableViewSelectedOrderButton();
        } else {
            JOptionPane.showMessageDialog(null, "Du måste köpa en Pizza");
        }
    }


}

