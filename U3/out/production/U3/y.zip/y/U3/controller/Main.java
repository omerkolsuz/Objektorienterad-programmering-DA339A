package controller;

/**
 * Main klass som skapar ett objekt av klassen Controller.
 */
public class Main {
    public static void main(String[] args) { Controller theController = new Controller();
    }
}
