package view;

public enum ButtonType {
    Add,
    Drinks,
    Food,
    MakePizza,
    NoChoice,
    Order,
    OrderHistory,
    ViewOrder,
    Delete,
}
