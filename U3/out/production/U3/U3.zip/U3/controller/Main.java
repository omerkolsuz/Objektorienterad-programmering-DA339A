package controller;

/**
 * @author Ömer Kolsuz och Ibrahim Akiel
 */

public class Main {
    public static void main(String[] args) {
        Controller theController = new Controller();
    }
}
